
## 🔗 Links
Planet Minecraft Profile - https://www.planetminecraft.com/member/thxlotl/

Modrinth Download - https://modrinth.com/datapack/cavernous

Interstella Discord - https://discord.gg/D7hyC7AWMJ

------------------------------------------------------------------------------------

## CAVERNOUS
Cavernous adds many new biomes and depth to the caves of minecraft.

## BAREBONES
Cavernous bare-bones is a version of Cavernous that includes only the cave
worldgen and no extra features, mobs, items, etc.

------------------------------------------------------------------------------------

## UPDATING FROM OLD CAVERNOUS VERSION

In order to update from a version released before Minecraft 1.20, you must delete the old
Cavernous datapack in your world's datapack folder and then put in the new datapack (the
one this read me belongs to) and drag the "CavernousCompatibility.zip" from the same folder
into the datapack folder as well. You only have to do this once, every other time you upgrade
to a new version the compatibility pack will still work.

------------------------------------------------------------------------------------

## Acknowledgements, Credits, & Dependencies

 - [Misodes Datapack Generators](https://misode.github.io/)

Created by thxlotl of Interstella Studios.
