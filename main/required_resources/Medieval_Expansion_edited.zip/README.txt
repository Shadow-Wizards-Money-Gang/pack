Rename the piece of Armour or Sword/Axe in an anvil to get the result you want
Weapons:
Sword
Arming Sword
V-Guard Sword
Falchion
Scimitar
Rapier
Billhook
Glaive
Halberd
Long Halberd
Pike
Pitchfork
Spear
Broadaxe
Axe
Crooked Axe
Straight Axe
Stiletto
Dagger
Zweihander
Warsword
Flamberge
Claymore
Hammer
Warhammer
Katana
Longsword
V-Guard Longsword
Flail
Spiked Mace
Mace
Bec De Corbin
Polehammer
Morning Star
Bardiche
Poleaxe

Helmets:
Armet Helmet
Bascinet Helmet
Barbute Helmet
Sallet Helmet
Frogmouth Helmet
Viking Helmet
Kettle Helmet
Nasal Helmet
Armet Slit Helmet
No Visor Barbute Helmet
Cage Helmet
Extended Cage Helmet
Great Helmet
Adorned Great Helmet
Maximillian Helmet
No Visor Bascinet Helmet

Chestplates:
Breastplate
Breastplate 2
Breastplate 3
Breastplate 4
Breastplate + Arms
Breastplate 2 + Arms
Breastplate 3 + Arms
Breastplate 4 + Arms
Breastplate + Besagew
Breastplate 2 + Besagew
Breastplate 3 + Besagew
Breastplate 4 + Besagew
Breastplate + Besagew Rims
Breastplate 2 + Besagew Rims
Breastplate + Rims
Breastplate 2 +Rims
Brigandine
Brigandine 2
Brigandine 3
Brigandine + Arms
Brigandine 2 + Arms
Brigandine 3 + Arms
Brigandine + Besagew
Brigandine 2 + Besagew
Brigandine 3 + Besagew
Brigandine + Besagew Rims
Brigandine + Rims
Mail Hauberk
Mail Hauberk 2
Mail Coif
Mail Boots

Leather Only
Mail Shirt